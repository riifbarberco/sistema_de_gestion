/**
 * RIIF — Sistema de reservas propio
 * Corre sobre Google Apps Script, pegado a tu hoja de cálculo.
 * Sin plataformas externas, sin comisiones, sin límite de citas.
 *
 * Antes de publicar, ajusta el bloque AJUSTES de abajo.
 */

// ==================== AJUSTES ====================
var NEGOCIO        = 'RIIF';
var TZ             = 'America/Bogota';
var WHATSAPP       = '573000000000';   // tu WhatsApp, formato 57 + número, sin + ni espacios
var EMAIL_AVISO    = '';               // tu correo para recibir aviso de cada reserva. Vacío = no envía
var DIRECCION      = 'Cartagena';      // aparece en la confirmación
var PASO_MIN       = 15;               // cada cuántos minutos se ofrece un cupo
var ANTICIPACION_H = 2;                // horas mínimas de anticipación para reservar
var DIAS_ADELANTE  = 21;               // qué tan lejos puede reservar el cliente
// =================================================

var HOJA_CONFIG   = 'Config';
var HOJA_HORARIOS = 'Horarios';
var HOJA_RESERVAS = 'Reservas';
var HOJA_BLOQUEOS = 'Bloqueos';
var DIAS = ['Lunes','Martes','Miércoles','Jueves','Viernes','Sábado','Domingo'];

// ---------- Punto de entrada web ----------
function doGet(e) {
  var id = e && e.parameter ? e.parameter.c : null;
  var tpl = HtmlService.createTemplateFromFile(id ? 'Cancelar' : 'Reservar');
  tpl.reservaId = id || '';
  return tpl.evaluate()
    .setTitle('Reservar en ' + NEGOCIO)
    .addMetaTag('viewport', 'width=device-width, initial-scale=1')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function include(nombre) {
  return HtmlService.createHtmlOutputFromFile(nombre).getContent();
}

// ---------- Utilidades ----------
function libro() { return SpreadsheetApp.getActiveSpreadsheet(); }

function aHHMM(v) {
  if (v === '' || v === null || v === undefined) return '';
  if (Object.prototype.toString.call(v) === '[object Date]') {
    return Utilities.formatDate(v, TZ, 'HH:mm');
  }
  var s = String(v).trim();
  var m = s.match(/^(\d{1,2})[:.](\d{2})/);
  return m ? ('0' + m[1]).slice(-2) + ':' + m[2] : s;
}

function aISO(v) {
  if (v === '' || v === null || v === undefined) return '';
  if (Object.prototype.toString.call(v) === '[object Date]') {
    return Utilities.formatDate(v, TZ, 'yyyy-MM-dd');
  }
  return String(v).trim().slice(0, 10);
}

function aMin(hhmm) {
  var p = String(hhmm).split(':');
  return parseInt(p[0], 10) * 60 + parseInt(p[1], 10);
}

function aTexto(min) {
  var h = Math.floor(min / 60), m = min % 60;
  return ('0' + h).slice(-2) + ':' + ('0' + m).slice(-2);
}

function diaSemana(iso) {
  var p = iso.split('-');
  var d = new Date(parseInt(p[0],10), parseInt(p[1],10) - 1, parseInt(p[2],10));
  return DIAS[(d.getDay() + 6) % 7];
}

function hoyISO() {
  return Utilities.formatDate(new Date(), TZ, 'yyyy-MM-dd');
}

function ahoraMin() {
  return aMin(Utilities.formatDate(new Date(), TZ, 'HH:mm'));
}

// ---------- Lectura de configuración ----------
function leerConfig() {
  var h = libro().getSheetByName(HOJA_CONFIG);
  if (!h) throw new Error('No existe la hoja Config.');

  var barberos = [];
  h.getRange('A5:B10').getValues().forEach(function (f) {
    if (String(f[0]).trim()) {
      barberos.push({ nombre: String(f[0]).trim(), comision: Number(f[1]) || 0 });
    }
  });

  var servicios = [];
  h.getRange('D5:F24').getValues().forEach(function (f) {
    if (String(f[0]).trim() && Number(f[2]) > 0) {
      servicios.push({
        nombre: String(f[0]).trim(),
        precio: Number(f[1]) || 0,
        duracion: Number(f[2])
      });
    }
  });

  return { barberos: barberos, servicios: servicios };
}

function leerHorarios() {
  var h = libro().getSheetByName(HOJA_HORARIOS);
  if (!h) return {};
  var mapa = {};
  h.getRange(2, 1, Math.max(h.getLastRow() - 1, 0), 4).getValues().forEach(function (f) {
    var barbero = String(f[0]).trim();
    var dia = String(f[1]).trim();
    var abre = aHHMM(f[2]);
    var cierra = aHHMM(f[3]);
    if (!barbero || !dia || !abre || !cierra) return;
    mapa[barbero] = mapa[barbero] || {};
    mapa[barbero][dia] = { abre: abre, cierra: cierra };
  });
  return mapa;
}

function ocupacion(barbero, iso) {
  var bloques = [];

  var hr = libro().getSheetByName(HOJA_RESERVAS);
  if (hr && hr.getLastRow() > 1) {
    hr.getRange(2, 1, hr.getLastRow() - 1, 14).getValues().forEach(function (f) {
      if (aISO(f[2]) !== iso) return;
      if (String(f[5]).trim() !== barbero) return;
      if (String(f[12]).trim() === 'Cancelada') return;
      bloques.push({ ini: aMin(aHHMM(f[3])), fin: aMin(aHHMM(f[4])) });
    });
  }

  var hb = libro().getSheetByName(HOJA_BLOQUEOS);
  if (hb && hb.getLastRow() > 1) {
    hb.getRange(2, 1, hb.getLastRow() - 1, 5).getValues().forEach(function (f) {
      if (aISO(f[1]) !== iso) return;
      var quien = String(f[0]).trim();
      if (quien && quien !== 'Todos' && quien !== barbero) return;
      bloques.push({ ini: aMin(aHHMM(f[2])), fin: aMin(aHHMM(f[3])) });
    });
  }

  return bloques;
}

// ---------- API para la página ----------
function getDatosIniciales() {
  var cfg = leerConfig();
  var horarios = leerHorarios();
  var dias = [];
  var base = new Date();
  for (var i = 0; i <= DIAS_ADELANTE; i++) {
    var d = new Date(base.getTime() + i * 86400000);
    var iso = Utilities.formatDate(d, TZ, 'yyyy-MM-dd');
    dias.push({
      iso: iso,
      dia: DIAS[(d.getDay() + 6) % 7],
      num: Utilities.formatDate(d, TZ, 'd'),
      mes: Utilities.formatDate(d, TZ, 'MMM')
    });
  }
  return {
    negocio: NEGOCIO,
    direccion: DIRECCION,
    servicios: cfg.servicios,
    barberos: cfg.barberos.map(function (b) { return b.nombre; }),
    dias: dias,
    tieneHorarios: Object.keys(horarios).length > 0
  };
}

function getCupos(barbero, iso, duracion) {
  duracion = Number(duracion);
  var horarios = leerHorarios();
  var cfg = leerConfig();
  var dia = diaSemana(iso);
  var esHoy = (iso === hoyISO());
  var corte = ahoraMin() + ANTICIPACION_H * 60;

  var candidatos = (barbero === '*')
    ? cfg.barberos.map(function (b) { return b.nombre; })
    : [barbero];

  var mapa = {};
  var abreMin = null, cierraMin = null;

  candidatos.forEach(function (nom) {
    var h = horarios[nom] && horarios[nom][dia];
    if (!h) return;
    var a = aMin(h.abre), c = aMin(h.cierra);
    abreMin = (abreMin === null) ? a : Math.min(abreMin, a);
    cierraMin = (cierraMin === null) ? c : Math.max(cierraMin, c);

    var ocupado = ocupacion(nom, iso);
    for (var t = a; t + duracion <= c; t += PASO_MIN) {
      if (esHoy && t < corte) continue;
      var choca = ocupado.some(function (b) { return t < b.fin && (t + duracion) > b.ini; });
      if (!choca) {
        if (!mapa[t]) mapa[t] = [];
        mapa[t].push(nom);
      }
    }
  });

  var cupos = Object.keys(mapa)
    .map(function (t) { return parseInt(t, 10); })
    .sort(function (x, y) { return x - y; })
    .map(function (t) { return { hora: aTexto(t), barberos: mapa[t] }; });

  var ocupados = [];
  if (barbero !== '*') {
    ocupados = ocupacion(barbero, iso).map(function (b) {
      return { ini: aTexto(b.ini), fin: aTexto(b.fin) };
    });
  }

  return {
    cupos: cupos,
    abre: abreMin === null ? '09:00' : aTexto(abreMin),
    cierra: cierraMin === null ? '20:00' : aTexto(cierraMin),
    ocupados: ocupados,
    cerrado: (abreMin === null)
  };
}

function crearReserva(d) {
  var lock = LockService.getScriptLock();
  try {
    lock.waitLock(20000);
  } catch (err) {
    return { ok: false, error: 'El sistema está ocupado. Intenta de nuevo en unos segundos.' };
  }

  try {
    var cfg = leerConfig();
    var servicio = cfg.servicios.filter(function (s) { return s.nombre === d.servicio; })[0];
    if (!servicio) return { ok: false, error: 'Ese servicio ya no está disponible.' };

    var nombre = String(d.nombre || '').trim();
    var tel = String(d.telefono || '').replace(/\D/g, '');
    if (nombre.length < 3) return { ok: false, error: 'Escribe tu nombre completo.' };
    if (tel.length < 7) return { ok: false, error: 'Escribe un número de teléfono válido.' };

    // Se revalida la disponibilidad con el candado puesto
    var estado = getCupos(d.barbero, d.fecha, servicio.duracion);
    var cupo = estado.cupos.filter(function (c) { return c.hora === d.hora; })[0];
    if (!cupo) {
      return { ok: false, error: 'Ese horario se acaba de ocupar. Escoge otro, por favor.' };
    }

    // Si el cliente eligió "cualquiera", se asigna al barbero con menos citas ese día
    var asignado = cupo.barberos[0];
    if (cupo.barberos.length > 1) {
      var conteo = {};
      cupo.barberos.forEach(function (n) { conteo[n] = ocupacion(n, d.fecha).length; });
      asignado = cupo.barberos.slice().sort(function (a, b) { return conteo[a] - conteo[b]; })[0];
    }

    var iniMin = aMin(d.hora);
    var finTxt = aTexto(iniMin + servicio.duracion);
    var id = 'R' + Utilities.formatDate(new Date(), TZ, 'yyMMdd') + '-' +
             Math.random().toString(36).slice(2, 7).toUpperCase();

    var h = libro().getSheetByName(HOJA_RESERVAS);
    h.appendRow([
      id, new Date(), d.fecha, d.hora, finTxt, asignado, servicio.nombre,
      servicio.duracion, servicio.precio, nombre, tel,
      String(d.email || '').trim(), 'Confirmada', String(d.notas || '').trim()
    ]);

    var resumen = {
      id: id, fecha: d.fecha, hora: d.hora, fin: finTxt, barbero: asignado,
      servicio: servicio.nombre, precio: servicio.precio,
      duracion: servicio.duracion, nombre: nombre, telefono: tel
    };

    enviarCorreos(resumen, String(d.email || '').trim());
    return { ok: true, reserva: resumen, whatsapp: WHATSAPP };

  } catch (err) {
    return { ok: false, error: 'No se pudo guardar la cita: ' + err.message };
  } finally {
    lock.releaseLock();
  }
}

function cancelarReserva(id) {
  var lock = LockService.getScriptLock();
  try { lock.waitLock(20000); } catch (e) { return { ok: false, error: 'Intenta de nuevo.' }; }
  try {
    var h = libro().getSheetByName(HOJA_RESERVAS);
    if (!h || h.getLastRow() < 2) return { ok: false, error: 'No encontramos esa cita.' };
    var datos = h.getRange(2, 1, h.getLastRow() - 1, 14).getValues();
    for (var i = 0; i < datos.length; i++) {
      if (String(datos[i][0]).trim() === String(id).trim()) {
        if (String(datos[i][12]).trim() === 'Cancelada') {
          return { ok: false, error: 'Esa cita ya estaba cancelada.' };
        }
        h.getRange(i + 2, 13).setValue('Cancelada');
        return {
          ok: true,
          reserva: {
            fecha: aISO(datos[i][2]), hora: aHHMM(datos[i][3]),
            barbero: datos[i][5], servicio: datos[i][6], nombre: datos[i][9]
          }
        };
      }
    }
    return { ok: false, error: 'No encontramos esa cita.' };
  } finally {
    lock.releaseLock();
  }
}

function verReserva(id) {
  var h = libro().getSheetByName(HOJA_RESERVAS);
  if (!h || h.getLastRow() < 2) return null;
  var datos = h.getRange(2, 1, h.getLastRow() - 1, 14).getValues();
  for (var i = 0; i < datos.length; i++) {
    if (String(datos[i][0]).trim() === String(id).trim()) {
      return {
        id: datos[i][0], fecha: aISO(datos[i][2]), hora: aHHMM(datos[i][3]),
        barbero: datos[i][5], servicio: datos[i][6], nombre: datos[i][9],
        estado: datos[i][12]
      };
    }
  }
  return null;
}

// ---------- Correos ----------
function enviarCorreos(r, emailCliente) {
  var fechaTxt = textoFecha(r.fecha);
  var precio = '$' + Number(r.precio).toLocaleString('es-CO');

  if (emailCliente && emailCliente.indexOf('@') > 0) {
    var url = ScriptApp.getService().getUrl() + '?c=' + r.id;
    var cuerpo =
      'Hola ' + r.nombre + ',\n\n' +
      'Tu cita en ' + NEGOCIO + ' quedó confirmada.\n\n' +
      'Servicio: ' + r.servicio + '\n' +
      'Cuándo: ' + fechaTxt + ' a las ' + r.hora + '\n' +
      'Con: ' + r.barbero + '\n' +
      'Valor: ' + precio + '\n' +
      'Dónde: ' + DIRECCION + '\n\n' +
      'Código de tu cita: ' + r.id + '\n' +
      'Si no puedes venir, cancela aquí y le damos el cupo a alguien más:\n' + url + '\n\n' +
      'Nos vemos.\n' + NEGOCIO;
    try {
      MailApp.sendEmail(emailCliente, 'Cita confirmada en ' + NEGOCIO + ' — ' + fechaTxt, cuerpo);
    } catch (e) { /* si se acaba la cuota de correos, la cita igual queda guardada */ }
  }

  if (EMAIL_AVISO && EMAIL_AVISO.indexOf('@') > 0) {
    try {
      MailApp.sendEmail(EMAIL_AVISO, 'Nueva cita: ' + fechaTxt + ' ' + r.hora + ' — ' + r.barbero,
        r.nombre + ' (' + r.telefono + ')\n' + r.servicio + ' · ' + precio + '\n' +
        fechaTxt + ' ' + r.hora + '–' + r.fin + '\nCon ' + r.barbero + '\nCódigo: ' + r.id);
    } catch (e) {}
  }
}

function textoFecha(iso) {
  var meses = ['enero','febrero','marzo','abril','mayo','junio','julio',
               'agosto','septiembre','octubre','noviembre','diciembre'];
  var p = iso.split('-');
  var d = new Date(parseInt(p[0],10), parseInt(p[1],10) - 1, parseInt(p[2],10));
  return DIAS[(d.getDay() + 6) % 7] + ' ' + parseInt(p[2],10) + ' de ' + meses[parseInt(p[1],10) - 1];
}

// ---------- Instalación (córrela UNA vez desde el editor) ----------
function configurarHojas() {
  var lb = libro();
  var cfg = leerConfig();

  var hr = lb.getSheetByName(HOJA_RESERVAS);
  if (!hr) {
    hr = lb.insertSheet(HOJA_RESERVAS);
    hr.appendRow(['ID','Creado','Fecha','Hora inicio','Hora fin','Barbero','Servicio',
                  'Duración (min)','Precio','Cliente','Teléfono','Email','Estado','Notas']);
    hr.getRange('D:E').setNumberFormat('@');
    hr.getRange('C:C').setNumberFormat('yyyy-mm-dd');
    hr.setFrozenRows(1);
    hr.getRange('A1:N1').setFontWeight('bold')
      .setBackground('#111111').setFontColor('#FFFFFF');
  }

  var hb = lb.getSheetByName(HOJA_BLOQUEOS);
  if (!hb) {
    hb = lb.insertSheet(HOJA_BLOQUEOS);
    hb.appendRow(['Barbero','Fecha','Desde','Hasta','Motivo']);
    hb.getRange('C:D').setNumberFormat('@');
    hb.getRange('B:B').setNumberFormat('yyyy-mm-dd');
    hb.setFrozenRows(1);
    hb.getRange('A1:E1').setFontWeight('bold')
      .setBackground('#111111').setFontColor('#FFFFFF');
    hb.getRange('A3').setValue('Usa "Todos" en Barbero para cerrar el local completo ese rato.');
  }

  var hh = lb.getSheetByName(HOJA_HORARIOS);
  if (!hh) {
    hh = lb.insertSheet(HOJA_HORARIOS);
    hh.appendRow(['Barbero','Día','Abre','Cierra']);
    hh.getRange('C:D').setNumberFormat('@');
    var filas = [];
    cfg.barberos.forEach(function (b) {
      DIAS.forEach(function (d) {
        if (d === 'Domingo') return;               // domingo cerrado por defecto
        filas.push([b.nombre, d, '09:00', '20:00']);
      });
    });
    if (filas.length) hh.getRange(2, 1, filas.length, 4).setValues(filas);
    hh.setFrozenRows(1);
    hh.getRange('A1:D1').setFontWeight('bold')
      .setBackground('#111111').setFontColor('#FFFFFF');
  }

  SpreadsheetApp.getUi().alert(
    'Listo.\n\nSe crearon las hojas Reservas, Bloqueos y Horarios.\n\n' +
    'Revisa Horarios: quedó de lunes a sábado, 9:00 a 20:00, domingo cerrado. ' +
    'Cambia lo que no aplique y borra las filas de los días que no abres.'
  );
}

/** Pasa las citas atendidas de Reservas a Registro. Úsala al cierre del día si quieres. */
function volcarAlRegistro(iso) {
  iso = iso || hoyISO();
  var hr = libro().getSheetByName(HOJA_RESERVAS);
  var hg = libro().getSheetByName('Registro');
  if (!hr || !hg || hr.getLastRow() < 2) return 0;

  var datos = hr.getRange(2, 1, hr.getLastRow() - 1, 14).getValues();
  var fila = hg.getLastRow() + 1;
  var n = 0;
  datos.forEach(function (f) {
    if (aISO(f[2]) !== iso) return;
    if (String(f[12]).trim() === 'Cancelada') return;
    hg.getRange(fila, 1).setValue(f[2]);       // Fecha
    hg.getRange(fila, 2).setValue(aHHMM(f[3])); // Hora
    hg.getRange(fila, 3).setValue(f[5]);       // Barbero
    hg.getRange(fila, 4).setValue(f[9]);       // Cliente
    hg.getRange(fila, 5).setValue(f[10]);      // Teléfono
    hg.getRange(fila, 6).setValue(f[6]);       // Servicio
    hg.getRange(fila, 16).setValue('Cita ' + f[0]); // Notas
    fila++; n++;
  });
  return n;
}

function menuPersonalizado() {
  SpreadsheetApp.getUi()
    .createMenu(NEGOCIO)
    .addItem('Instalar hojas del sistema', 'configurarHojas')
    .addItem('Pasar citas de hoy al Registro', 'volcarHoy')
    .addToUi();
}

function onOpen() { menuPersonalizado(); }

function volcarHoy() {
  var n = volcarAlRegistro();
  SpreadsheetApp.getUi().alert('Se pasaron ' + n + ' citas al Registro.\n\n' +
    'Falta que completes estado, método de pago y propina en cada fila.');
}
